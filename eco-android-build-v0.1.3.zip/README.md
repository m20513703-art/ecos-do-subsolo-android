# Ecos do Subsolo — Android

Protótipo Android 0.1.3 do jogo em primeira pessoa, feito como aplicativo de tela cheia com WebView local (HTML, CSS e JavaScript empacotados no APK). Inclui imagem de logo e sprite do zumbi dentro do pacote; não depende da internet durante o jogo.

## História da demo

Lia Nascimento, técnica da fictícia Vértice Biológica, precisa recuperar o crachá de manutenção, religar o gerador auxiliar e escapar levando um registro sobre o organismo Eco, que reage a vibrações e ruídos. A estação, companhia, personagem, organismo e acontecimentos são originais.

## Controles para celular

D-pad com setas grandes para movimento; arraste na área livre do lado direito da tela para olhar.

## Gerar APK de teste

O workflow em `.github/workflows/android.yml` compila um APK de depuração com Gradle/Android SDK, faz verificações mínimas e anexa o APK à release `v0.1.0`.

`./gradlew assembleDebug` ou `gradle assembleDebug` (com JDK 17 e Android SDK).
